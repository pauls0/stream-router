"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
var aws_sdk_1 = require("aws-sdk");
var netmask_1 = require("netmask");
aws_sdk_1.config.update({
    region: "ap-southeast-2"
});
var docClient = new aws_sdk_1.DynamoDB.DocumentClient();
exports.handler = function (event) { return __awaiter(void 0, void 0, void 0, function () {
    var ip, network, cdn, host, payload, response;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (event.queryStringParameters == null ||
                    event.queryStringParameters == undefined) {
                    return [2 /*return*/, {
                            statusCode: 400,
                            headers: {
                                "content-type": "application/json"
                            },
                            isBase64Encoded: false,
                            body: JSON.stringify({
                                message: "Error: queryStringParameter 'ip' not found"
                            })
                        }];
                }
                ip = event.queryStringParameters.ip;
                return [4 /*yield*/, getNetwork(iptoint(ip))];
            case 1:
                network = _a.sent();
                return [4 /*yield*/, getCDN(network)];
            case 2:
                cdn = _a.sent();
                return [4 /*yield*/, getHost(cdn, ip)];
            case 3:
                host = _a.sent();
                payload = {
                    host: host
                };
                response = {
                    statusCode: 200,
                    body: JSON.stringify(payload)
                };
                return [2 /*return*/, response];
        }
    });
}); };
function getNetwork(ip) {
    return __awaiter(this, void 0, void 0, function () {
        var network;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, docClient
                        .scan({
                        TableName: "stream-router-table-cdir-network",
                        FilterExpression: "#f <= :ip and #l >= :ip",
                        ExpressionAttributeNames: {
                            "#f": "first",
                            "#l": "last"
                        },
                        ExpressionAttributeValues: {
                            ":ip": ip
                        }
                    })
                        .promise()
                        .then(function (data) {
                        if (data.Count == 0) {
                            console.error("Error: No network found for ip: " + ip);
                            network = 0;
                        }
                        else {
                            network = data.Items[0].network;
                        }
                    })["catch"](function (err) {
                        console.error("err", err);
                    })];
                case 1:
                    _a.sent();
                    return [2 /*return*/, network];
            }
        });
    });
}
function getCDN(network) {
    return __awaiter(this, void 0, void 0, function () {
        function getMapping(networkKey) {
            return __awaiter(this, void 0, void 0, function () {
                var params, response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            params = {
                                TableName: "stream-router-table-mappings",
                                Key: {
                                    network: networkKey
                                }
                            };
                            return [4 /*yield*/, docClient.get(params).promise()];
                        case 1:
                            response = _a.sent();
                            return [2 /*return*/, response.Item];
                    }
                });
            });
        }
        var mapping;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    return [4 /*yield*/, getMapping("" + network)];
                case 1:
                    mapping = _a.sent();
                    return [2 /*return*/, mapping.cdn];
            }
        });
    });
}
function getDefaultHost(cdn) {
    return __awaiter(this, void 0, void 0, function () {
        var host;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, docClient
                        .get({
                        TableName: "stream-router-table-cdn-host-defaults",
                        Key: {
                            cdn: cdn
                        }
                    })
                        .promise()
                        .then(function (data) {
                        if (data.Item == undefined) {
                            console.error("Error: No host found for cdn: " + cdn);
                        }
                        else {
                            host = data.Item.host;
                        }
                    })["catch"](function (err) {
                        console.error("err", err);
                    })];
                case 1:
                    _a.sent();
                    return [2 /*return*/, host];
            }
        });
    });
}
function getHost(cdn, ip) {
    return __awaiter(this, void 0, void 0, function () {
        var mappings, host;
        var _this = this;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    host = null;
                    return [4 /*yield*/, docClient
                            .query({
                            TableName: "stream-router-table-cdn-host",
                            KeyConditionExpression: "#cdn = :cdn",
                            ExpressionAttributeNames: {
                                "#cdn": "cdn"
                            },
                            ExpressionAttributeValues: {
                                ":cdn": cdn
                            }
                        })
                            .promise()
                            .then(function (data) {
                            if (data.Count == 0) {
                                console.error("Error: No host found for cdn: " + cdn);
                            }
                            else {
                                mappings = data.Items;
                            }
                        })["catch"](function (err) {
                            console.error("err", err);
                        })];
                case 1:
                    _a.sent();
                    mappings.forEach(function (mapping) { return __awaiter(_this, void 0, void 0, function () {
                        var cidr;
                        return __generator(this, function (_a) {
                            cidr = new netmask_1.Netmask(mapping.cidr);
                            if (cidr.contains(ip)) {
                                host = mapping.host;
                            }
                            return [2 /*return*/];
                        });
                    }); });
                    if (!(host == null)) return [3 /*break*/, 3];
                    return [4 /*yield*/, getDefaultHost(cdn)];
                case 2:
                    host = _a.sent();
                    _a.label = 3;
                case 3: return [2 /*return*/, host];
            }
        });
    });
}
function iptoint(ip) {
    var octets = ip.split(".").map(function (octet) { return parseInt(octet); });
    var ip_int = octets[0] * Math.pow(256, 3) + octets[1] * Math.pow(256, 2) + octets[2] * 256 + octets[3];
    return ip_int;
}
function inttoip(int) {
    var octet1 = (int >> 24) & 255;
    var octet2 = (int >> 16) & 255;
    var octet3 = (int >> 8) & 255;
    var octet4 = int & 255;
    return "" + octet1 + "." + octet2 + "." + octet3 + "." + octet4;
}
// async function run() {
//   var ip = 201326593;
//   var network = await getNetwork(ip);
//   var cdn = await getCDN(network);
//   var host = await getHost(cdn);
//   console.log("network", network);
//   console.log("cdn", cdn);
//   console.log("host", host);
// }
// run();
